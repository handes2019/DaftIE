﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();

            headerStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;

            this.dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = headerStyle;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToAddRows = false;
            //this.dataGridView1.DataSource = DataBindingByList1(); 
            //this.dataGridView1.DataSource = DataBindingByList2(); 
            //this.dataGridView1.DataSource = DataBindingByDataTable(); 
            //this.dataGridView1.DataSource = DataBindingByBindingSource();
            //DataGridViewComboBoxColumn btn = new DataGridViewComboBoxColumn();


            //using (SqlConnection conn = new SqlConnection(strCon))
            //{

            //    SqlDataAdapter sda = new SqlDataAdapter("Select ID,DeptName From DepartMent  order by ID", conn);
            //    DataSet Ds = new DataSet();

            //    sda.Fill(Ds, "Dept");

            //    //必须和数据库字段名保持一致,此字段中的数据为前台显示在datagridview的数据
            //    btn.DataPropertyName = "DeptName";

            //    btn.DataSource = Ds.Tables["Dept"];
            //    btn.ValueMember = "ID";
            //    btn.DisplayMember = "DeptName";
               

            //    this.dataGridView1.Columns.Add(btn);
            //}

            DataSourceBinding();

        }


        /// <summary> 
        /// IList接口（包括一维数组，ArrayList等） 
        /// </summary> 
        /// <returns></returns> 
        //private ArrayList DataBindingByList1()
        //{
        //    ArrayList Al = new ArrayList();
        //    Al.Add(new PersonInfo("a", "-1"));
        //    Al.Add(new PersonInfo("b", "-2"));
        //    Al.Add(new PersonInfo("c", "-3"));
        //    return Al;
        //}

        /// <summary> 
        /// IList接口（包括一维数组，ArrayList等） 
        /// </summary> 
        /// <returns></returns> 
        private ArrayList DataBindingByList2()
        {
            ArrayList list = new ArrayList();
            for (int i = 0; i < 10; i++)
            {
                list.Add(new DictionaryEntry(i.ToString(), i.ToString() + "_List"));
            }
            return list;
        }


        /// <summary> 
        /// IListSource接口（DataTable、DataSet等） 
        /// </summary> 
        /// <returns></returns> 
        private DataTable DataBindingByDataTable()
        {
            DataTable dt = new DataTable();
            DataColumn dc1 = new DataColumn("Name");
            DataColumn dc2 = new DataColumn("Value");

            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);

            for (int i = 1; i <= 10; i++)
            {
                DataRow dr = dt.NewRow();
                dr[0] = i;
                dr[1] = i.ToString() + "_DataTable";
                dt.Rows.Add(dr);
            }

            return dt;
        }


        /// <summary> 
        /// IBindingListView接口（如BindingSource类） 
        /// </summary> 
        /// <returns></returns> 
        private BindingSource DataBindingByBindingSource()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            for (int i = 0; i < 10; i++)
            {
                dic.Add(i.ToString(), i.ToString() + "_Dictionary");
            }
            return new BindingSource(dic, null);
        }

        private static readonly string strCon = ConfigurationManager.ConnectionStrings["strCon"].ConnectionString;
        private void DataSourceBinding()
        {
            //string strCon = ConfigurationManager.ConnectionStrings["strCon"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(strCon))
            {

                SqlDataAdapter sda = new SqlDataAdapter("Select ID,Name,Remark,Department_ID From Friends  order by ID", conn);
                DataSet Ds = new DataSet();
               
                sda.Fill(Ds, "Friends");
                Ds.Tables["Friends"].Columns.Add("操作", System.Type.GetType("System.Boolean")).SetOrdinal(0);
                
              
                 
                
                
                //使用DataSet绑定时，必须同时指明DateMember 
                this.dataGridView1.DataSource = Ds;
                this.dataGridView1.DataMember = "Friends";


                sda = new SqlDataAdapter("Select * From DepartMent  order by ID", conn);
                Ds = new DataSet();
              
                sda.Fill(Ds, "DepartMent");
                Ds.Tables["DepartMent"].Columns.Add("操作", System.Type.GetType("System.Boolean")).SetOrdinal(0);

                this.dataGridView2.DataSource = Ds;
                this.dataGridView2.DataMember = "DepartMent";



                //也可以直接用DataTable来绑定 
                //this.dataGridView1.DataSource = Ds.Tables["T_Class"];


               

            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(strCon))
            {
                conn.Open();
                SqlCommand com = new SqlCommand("delete from Friends where Name='" + textBox1.Text.Trim() + "'", conn);
                com.ExecuteNonQuery();
               
            }
            DataSourceBinding();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(strCon))
            {
                conn.Open();
                SqlCommand com = new SqlCommand("select ID,Name,Remark from Friends where Name='" + textBox1.Text.Trim() + "'", conn);
                SqlDataReader sdr = com.ExecuteReader();
                sdr.Read();
                if(sdr.HasRows)
                {
                    int deptid = SaveDepart(textBox2.Text.Trim());
                    com = new SqlCommand("update Friends set Remark='" + textBox3.Text.Trim() + "',Department_ID="+deptid+"  where Name='" + textBox1.Text.Trim() + "'", conn);
                    com.ExecuteNonQuery();

                }
                else
                {
                    int deptid = SaveDepart(textBox2.Text.Trim());
                    com = new SqlCommand("insert into Friends (Name,Remark,Department_ID) values ('" + textBox1.Text.Trim() + "','"+textBox3.Text.Trim()+"'," + deptid + " )", conn);
                    com.ExecuteNonQuery();
                }
            }
            DataSourceBinding();
         }


        private int SaveDepart(string depart)
        {
            using (SqlConnection conn = new SqlConnection(strCon))
            {
                conn.Open();
                SqlCommand com = new SqlCommand("Select * From DepartMent where DeptName='" + depart + "'", conn);
                SqlDataReader sdr = com.ExecuteReader();
                sdr.Read();
                if (!sdr.HasRows)
                {
                    SqlCommand comm = new SqlCommand("insert into DepartMent  (DeptName) values ('" + depart + "')" , conn);
                    int row = comm.ExecuteNonQuery();
                    return row;
                }
                else
                {
                    return int.Parse(sdr["ID"].ToString());
                }

            }
        }

        private void dataGridView2_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {

            e.Control.Controls.Clear();
            if (e.Control is DataGridViewTextBoxEditingControl && this.dataGridView2.CurrentCell.ColumnIndex == 2)
            {
                using (SqlConnection conn = new SqlConnection(strCon))
                {
                    ComboBox btn = new ComboBox();
                    e.Control.Controls.Add(btn);
                    btn.Dock = DockStyle.Fill;
                    btn.Cursor = Cursors.Default;
               

                    SqlDataAdapter sda = new SqlDataAdapter("Select ID,DeptName From DepartMent  order by ID", conn);
                    DataSet Ds = new DataSet();

                    sda.Fill(Ds, "Dept");
               
                    
                    btn.DataSource = Ds.Tables["Dept"];
                    btn.ValueMember = "ID";
                    btn.DisplayMember = "DeptName";
                    btn.SelectedValueChanged += delegate
                    {
                        this.dataGridView2.CurrentCell.Value = btn.Text;
                    };
                }
            }

        }
    }
}
